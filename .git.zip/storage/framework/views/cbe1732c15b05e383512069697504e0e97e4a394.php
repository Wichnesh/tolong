<?php echo $__env->make('skins.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('skins.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="font-weight-bold mb-0">Edit Sector</h4>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-md-6 grid-margin ">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Edit Sector</h4>
                        <form method="POST" action="<?php echo e(route('update.sector')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Upload Category</label>
                                <input type="hidden" name="sec_id" value="<?php echo e($sector->id); ?>" />
                                <input type="text" class="form-control" placeholder="Add Sector" aria-label=""
                                    name="sector"
                                    value="<?php echo e(isset($sector->sector_name) ? $sector->sector_name : ''); ?>">
                            </div>
                            <button type="submit" class="btn btn-primary mr-2">Update</button>
                    </div>
                </div>
                </form>
            </div>
            
        </div>
        
        <!-- content-wrapper ends -->
        <?php echo $__env->make('skins.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Xampp\htdocs\maintance\resources\views/skins/inc/edit/sectorsEdit.blade.php ENDPATH**/ ?>