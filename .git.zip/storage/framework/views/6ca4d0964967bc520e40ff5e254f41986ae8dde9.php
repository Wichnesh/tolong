<?php echo $__env->make('skins.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('skins.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="font-weight-bold mb-0" style="margin-left:17px;">Add Employer</h4>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="col-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <form class="form-sample" action="<?php echo e(route('insert.employer')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                       
                        <h4 class="card-title">Personal Details</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="name" />
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Address</label>
                                    <div class="col-sm-9">
                                        <textarea type="text" class="form-control" rows="5" name="address"></textarea>
                                        <?php if($errors->has('address')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Phone Number</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="phone" />
                                        <?php if($errors->has('phone')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                
                            </div>
                        </div>
                        <p class="card-description">
                            Passport Details
                        </p>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Issue Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" placeholder="dd/mm/yyyy"
                                            name="ps_ise" />
                                        <?php if($errors->has('ps_ise')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('ps_ise')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Expiry Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" placeholder="dd/mm/yyyy"
                                            name="ps_ex" />
                                        <?php if($errors->has('ps_ex')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('ps_ex')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Labour's License</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="lic">
                                        <?php if($errors->has('lic')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('lic')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Perkeso Employer's Code</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="per">
                                        <?php if($errors->has('per')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('per')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Sector</label>
                                    <div class="col-sm-9">
                                        <select class="form-control" id="multiple-checkboxes" multiple="multiple"
                                            name="sectors[]">
                                            <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($sector->id); ?>"><?php echo e($sector->sector_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('sectors')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('sectors')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                     
                                </div>
                                
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Quota</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="quota">
                                        <?php if($errors->has('quota')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('quota')); ?></span>
                                        <?php endif; ?>
                                    </div>
                        </div>
                            </div>
                        </div>
                        
                        
                        
                        
                        <button type="submit" class="btn btn-primary text-center">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->


    <?php echo $__env->make('skins.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
    
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
    <script>
        $(document).ready(function() {
            $('#multiple-checkboxes').multiselect({
                includeSelectAllOption: true,
            });
        });
    </script>
<?php /**PATH D:\Xampp\htdocs\maintance\resources\views/skins/inc/uploads/addEmployer.blade.php ENDPATH**/ ?>