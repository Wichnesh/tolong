<?php echo $__env->make('skins.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('skins.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h4 class="font-weight-bold mb-0">Current Month Expires</h4>
                </div>
              </div>
            </div>
          </div>
         
         
          <div class="row">
             
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Workers List</h4>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            User
                          </th>
                          <th>
                            First name
                          </th>
                          <th>
                            Category
                          </th>
                          <th>
                           Sub Category
                          </th>
                          <th>
                            Passport Number
                          </th>
                          <th>
                            Deadline
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td class="py-1">
                            <img src="../../images/faces/face1.jpg" alt="image"/>
                          </td>
                          <td>
                            Herman Beck
                          </td>
                          <td>
                           Textile
                          </td>
                          <td>
                           Textile 1
                          </td>
                          <td>
                            XYZ
                          </td>
                          <td>
                            October 20, 2023
                          </td>
                        </tr>
                       
                        <tr>
                          <td class="py-1">
                            <img src="../../images/faces/face3.jpg" alt="image"/>
                          </td>
                          <td>
                            John Richards
                          </td>
                          <td>
                           Textile
                          </td>
                          <td>
                           Textile 1
                          </td>
                          <td>
                           XYZ
                          </td>
                          <td>
                            October 19, 2023
                          </td>
                        </tr>
                        <tr>
                          <td class="py-1">
                            <img src="../../images/faces/face4.jpg" alt="image"/>
                          </td>
                          <td>
                            Peter Meggik
                          </td>
                          <td>
                           Textile
                          </td>
                          <td>
                           Textile 1
                          </td>
                          <td>
                            XYZ
                          </td>
                          <td>
                            October 18, 2023
                          </td>
                        </tr>
                        <tr>
                          <td class="py-1">
                            <img src="../../images/faces/face5.jpg" alt="image"/>
                          </td>
                          <td>
                            Edward
                          </td>
                           <td>
                           Textile
                          </td>
                          <td>
                           Textile 1
                          </td>
                          <td>
                          XYZ
                          </td>
                          <td>
                            October 25, 2023
                          </td>
                        </tr>
                        <tr>
                          <td class="py-1">
                            <img src="../../images/faces/face6.jpg" alt="image"/>
                          </td>
                          <td>
                            John Doe
                          </td>
                          <td>
                           Textile
                          </td>
                          <td>
                           Textile 1
                          </td>
                          <td>
                            XYZ
                          </td>
                          <td>
                            October 20, 2023
                          </td>
                        </tr>
                        <tr>
                          <td class="py-1">
                            <img src="../../images/faces/face7.jpg" alt="image"/>
                          </td>
                          <td>
                            Henry Tom
                          </td>
                           <td>
                           Textile
                          </td>
                          <td>
                           Textile 1
                          </td>
                          <td>
                            XYZ
                          </td>
                          <td>
                            October 16, 2023
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <!-- content-wrapper ends -->    
<?php echo $__env->make('skins.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\maintance\resources\views/skins/inc/passportExpireList.blade.php ENDPATH**/ ?>