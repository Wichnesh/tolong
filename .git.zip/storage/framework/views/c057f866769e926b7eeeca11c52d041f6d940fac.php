<?php echo $__env->make('skins.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('skins.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- partial -->

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="font-weight-bold mb-0" style="margin-left:17px;">Edit Employee</h4>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="col-12 grid-margin">
            <div class="card">
                <div class="card-body"> <h4 class="card-title">1.Employer Details</h4>
                    <form class="form-sample" action="<?php echo e(route('update.employee')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Employer Name</label>
                                    <div class="col-sm-9">
                                         <select class="form-control" name="emp_name" id="emp_id" <?php if(isset($emp_edit->employer_id)): ?> selected <?php endif; ?>>
                                            <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value=<?php echo e($employer->id); ?>><?php echo e($employer->emp_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Sector</label>
                                    <div class="col-sm-9">
                                         <select class="form-control" name="emp_sector" id="emp_sector" <?php if(isset($emp_edit->sector_id)): ?> selected <?php endif; ?> required>
                                           
                                        </select>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <h4 class="card-title">2.Personal Details</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Name</label>
                                    <div class="col-sm-9">
                                        <input type="hidden"name="employee_id" value="<?php echo e($emp_edit->id); ?>" />
                                        <input type="text" class="form-control" name="f_name"  value="<?php echo e(isset($emp_edit->emp_fname) ? $emp_edit->emp_fname : ''); ?>" />
                                    </div>

                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Middle Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="m_name" value="<?php echo e(isset($emp_edit->emp_mname) ? $emp_edit->emp_mname : ''); ?>"/>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Last Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="l_name" value="<?php echo e(isset($emp_edit->emp_lname) ? $emp_edit->emp_lname : ''); ?>"/>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Date of Birth</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" placeholder="dd/mm/yyyy" value="<?php echo e(isset($emp_edit->emp_dob) ?  $emp_edit->emp_dob : ''); ?>"
                                            name="dob" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p class="card-description">
                           3.Passport Details
                        </p>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Passport Number</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" placeholder="" name="ps_num"  value="<?php echo e(isset($emp_edit->passport_number) ? $emp_edit->passport_number : ''); ?>"/>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Issue Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" placeholder="dd/mm/yyyy" value="<?php echo e(isset($emp_edit->passport_is_date) ? $emp_edit->passport_is_date : ''); ?>"
                                            name="ps_ise" />
                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Expiry Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" placeholder="dd/mm/yyyy" value="<?php echo e(isset($emp_edit->passport_ex_date) ? $emp_edit->passport_ex_date : ''); ?>"
                                            name="ps_ex" />
                                    </div>

                                </div>
                            </div>
                        </div>
                        <p class="card-description">
                            4.Work Pass Details
                        </p>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Work Pass Year</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" name="wrk_yr" value="<?php echo e(isset($emp_edit->workpass_yr) ?  $emp_edit->workpass_yr : ''); ?>">
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Sticker Number</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="st_num" value="<?php echo e(isset($emp_edit->sticker_number) ? $emp_edit->sticker_number : ''); ?>" />
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Issue Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" placeholder="dd/mm/yyyy" value="<?php echo e(isset($emp_edit->workpass_is_date) ? $emp_edit->workpass_is_date : ''); ?>"
                                            name="wrkpass_ise" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Expiry Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control" placeholder="dd/mm/yyyy" value="<?php echo e(isset($emp_edit->workpass_ex_date) ? $emp_edit->workpass_ex_date : ''); ?>"
                                            name="wrkpass_exp" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Remarks</label>
                                    <div class="col-sm-9">
                                        <textarea type="text" class="form-control" placeholder="" name="remarks" rows="5"><?php echo e(isset($emp_edit->remarks) ? $emp_edit->remarks : ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        
                        
                        
                        
                        <button type="submit" class="btn btn-primary text-center">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->


    <?php echo $__env->make('skins.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function(){
      $('#emp_id').on('click',function(){
        var empId = $(this).val();
        console.log(empId) 
        $.ajax({
            url:'/get-sectors/' + empId,
            method:'GET',
            success:function(data){
                // console.log(response)
                $('#emp_sector').empty();
                 $.each(data, function(index, sector) {
                        $('#emp_sector').append('<option value="' + sector.id + '">' + sector.sector_name + '</option>');
                    });
              
            },
            error:function(){
                console.log(error)
            }
        })
      });  
    });
</script><?php /**PATH D:\Xampp\htdocs\maintance\resources\views/skins/inc/edit/employeeEdit.blade.php ENDPATH**/ ?>